/*
 * Author: petropavel
 * Created at: 2014-09-14 23:36:11 +0600
 *
 */

--
-- This is a example code genereted automaticaly
-- by pgxn-utils.

SET client_min_messages = warning;

BEGIN;

DROP TYPE rrule CASCADE;

COMMIT;
